<?php

	// Знаю что данные в запросе должены быть экранированы;
	// Забыл как это делать, а гуглить уже не успеваю.

	const SELECT_ALL_PRODUCTS = 'SELECT * FROM marlin_task_products';
?>