<?php require_once 'header.php'; ?>

<section class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="/">На главную</a>
        </div>
        <div class="col-md-4">
            <img src="" alt="">
        </div>
        <div class="col-md-8">
            <div>Категория товара</div>
            <h1>Название товара</h1>
            <div>Полное описание</div>
        </div>
    </div>
</section>
<footer>

</footer>
</body>
</html>